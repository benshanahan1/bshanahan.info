These .java files can be used in your own Java projects. Simply create constructors:
	Coder(String text, double key);