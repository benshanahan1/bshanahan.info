function d = distance(x1, y1, x2, y2)
% function d = distance(x1, y1, x2, y2)
% Benjamin Shanahan, 20141209
% Returns distance between points. All parameters are vectors, returns a
% vector as well.

% Error checking
if ~isequal(size(x1), size(y1), size(x2), size(y2))
    error('All inputted vectors must have same size.');
end
if ~isvector(x1) || ~isvector(y1) || ~isvector(x2) || ~isvector(y2)
    error('All inputs must be vectors.');
end

% Calculate distance and return
d = sqrt((x2-x1).^2 + (y2-y1).^2);