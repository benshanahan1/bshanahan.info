function equal = fuzzy_equals(a, b, range)
% function fuzzy_equals(a, b, error)
% Benjamin Shanahan 20141209
% Check if two values are within a certain range of each other.

if abs(a - b) < range
    equal = 1;
else
    equal = 0;
end

return;