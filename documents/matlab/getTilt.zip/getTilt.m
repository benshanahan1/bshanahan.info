function tilt = getTilt(no_tilt_range, fx, fy, rx, ry, lx, ly)
% function tilt = getTilt(no_tilt_range, fx, fy, rx, ry, lx, ly)
% Benjamin Shanahan 20141215
% Takes three equal length position vectors for rat head LEDs arranged in a
% triangular formation. Function goes through data and if at any point
% there is significant tilt deviation (greater than no_tilt_range), this is
% recorded and returned.

% calculate distances between LEDs (these values are EDGES not POINTS)
dist_left = distance(fx, fy, lx, ly);
dist_right = distance(fx, fy, rx, ly);
dist_back = distance(lx, ly, rx, ry);

% find where distances indicate tilt (not flat)
diff_left2right = abs(dist_left - dist_right);
diff_left2back = abs(dist_left - dist_back);
diff_right2back = abs(dist_right - dist_back);

% record where there is tilt (use 0s for NO TILT and 1s for TILT)
tilt = false(1, numel(lx)); % create vector of logical(0) false values
for i = 1 : numel(lx)
    if ~fuzzy_equals(diff_left2right(i), diff_left2back(i), no_tilt_range)
        tilt(i) = true;
    end
    if ~fuzzy_equals(diff_left2right(i), diff_right2back(i), no_tilt_range)
        tilt(i) = true;
    end
    if ~fuzzy_equals(diff_left2back(i), diff_right2back(i), no_tilt_range)
        tilt(i) = true;
    end
end

% return
return;