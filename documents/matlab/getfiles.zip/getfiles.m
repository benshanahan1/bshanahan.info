function fileList = getfiles(parentdir, str2match)
% fileList = getfiles(parentdir, str2match)
%
% Benjamin Shanahan, 20150409.
%
% Returns a list of all files in given directory, including subdirectories,
% matching a specified string.

% Get a list of all files in given directory.
fileList = subdir(parentdir);

% Extract a list of files containing keyword.
idxLFP = not(cellfun('isempty', strfind(fileList, str2match)));

% Return discovered files.
fileList = fileList(idxLFP);

return