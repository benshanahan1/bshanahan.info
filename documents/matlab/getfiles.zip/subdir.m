function fileList = subdir(dirName, regexp)
% fileList = subdir(dirName, regexp)
%
% Code modified by Benjamin Shanahan, 20150409.
%
% Returns list of all files in a directory, including subdirectories,
% matching a specific Regex pattern.
%
% Source: http://stackoverflow.com/questions/2652630/how-to-get-all-files-
%         under-a-specific-directory-in-matlab

dirData = dir(dirName);
dirIndex = [dirData.isdir];
fileList = {dirData(~dirIndex).name}';

useRegex = exist('pattern', 'var');

if ~isempty(fileList)
    fileList = cellfun(@(x) fullfile(dirName, x), fileList, ...
        'UniformOutput', false);
    
    if useRegex
        matchstart = regexp(fileList, regexp);
        fileList = fileList(~cellfun(@isempty, matchstart));
    end
end

subDirs = {dirData(dirIndex).name};
validIndex = ~ismember(subDirs, {'.','..'});

for iDir = find(validIndex)
    nextDir = fullfile(dirName, subDirs{iDir});
    
    if useRegex
        fileList = [fileList; subdir(nextDir, regexp)];
    else
        fileList = [fileList; subdir(nextDir)];
    end
end

return