fprintf('BE SURE TO COMMENT OUT id IN analyze_popstats.m...\n');
pause;

stime = tic;

id = '2d_k';
analyze_popstats;
distdep2d_frV = frV;
distdep2d_xV = xV;

id = '3d_k';
analyze_popstats;
distdep3d_frV = frV;
distdep3d_xV = xV;

close all;

figure;

subplot(211);
plot(distdep2d_xV, distdep2d_frV, '.-k', 'MarkerSize', 16);
title('Population Mean Firing Rate vs K');
ylabel('Mean Firing Rate (Hz)');
legend('Distance-Dependent 2D', 'Location', 'SouthWest');
xlim([-250 -50]);
set(gca, 'XTick', linspace(-250, -50, 6));
grid; grid('minor');

subplot(212);
plot(distdep3d_xV, distdep3d_frV, '.-k', 'MarkerSize', 16);
xlabel('K (decay constant)');
ylabel('Mean Firing Rate (Hz)');
legend('Distance-Dependent 3D', 'Location', 'SouthWest');
xlim([-125 -25]);
set(gca, 'XTick', linspace(-125, -25, 6));
grid; grid('minor');

toc(stime);