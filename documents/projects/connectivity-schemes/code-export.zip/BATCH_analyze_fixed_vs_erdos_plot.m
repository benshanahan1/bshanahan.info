% generate Fixed vs Erdos mean firing rate comparison plot

numBins = 15;

load('../data/NETWORK_20150510231502_random_normalParams.mat');
analysis; drawnow; close all; drawnow;
[randomcounts, randomcenters] = hist(neuron_mean_fr, numBins);
random_meanfr = full(neuron_mean_fr);

load('../data/NETWORK_20150510225317_fixed-in_normalParams.mat');
analysis; drawnow; close all; drawnow;
[fixedcounts, fixedcenters] = hist(neuron_mean_fr, numBins);
fixed_meanfr = full(neuron_mean_fr);

figure;
grid;

hold on;
plot(randomcenters, randomcounts, '.-b', 'MarkerSize', 16);
plot(fixedcenters, fixedcounts, '.-r', 'MarkerSize', 16);
ylimits = get(gca, 'ylim');
plot([mean(random_meanfr) mean(random_meanfr)], ylimits, '--b');
plot([mean(fixed_meanfr) mean(fixed_meanfr)], ylimits, '--r');
hold off;

legend(sprintf('Random: %0.2f Hz', mean(random_meanfr)), ...
    sprintf('Fixed: %0.2f Hz', mean(fixed_meanfr)), ...
    'Location', 'best')
title('Fixed vs Erdos Connectivity Scheme');
xlabel('Mean Firing Rate (Hz)')
ylabel('Frequency')

% check if the two mean firing rate distributions come from the same
% distribution or not using Two-sample Kolmogorov-Smirnov goodness-of-fit
% hypothesis test; H = 1 (reject null hypothesis at alpha = .05 that two
% distributions come from same parent distribution)
[H_ks, P_ks, ks2stat] = kstest2(random_meanfr, fixed_meanfr);
if H_ks == 1
    fprintf('REJECT: the distributions are significantly different.\n');
else
    fprintf('FAILURE to REJECT: the distributions may come from same parent distribution.\n');
end
fprintf(sprintf('H=%d with P=%d.\n', H_ks, P_ks));

% check if fixed-input distribution is normal using chi-squared goodness of
% fit statistical test
[H_chi, P_chi, stats_chi] = chi2gof(fixedcounts);
if H_chi == 1
    fprintf('REJECT: the distribution is significantly different from a normal distribution.\n');
else
    fprintf('FAILURE to REJECT: the distribution is not significantly different from a normal distribution.\n');
end
fprintf(sprintf('H=%d with P=%d.\n', H_chi, P_chi));

% plot cumulative frequency distributions and compare them
[f_fixed, x_fixed] = ecdf(fixed_meanfr);
[f_random, x_random] = ecdf(random_meanfr);
figure; hold on; grid; grid('minor');
plot(x_fixed, f_fixed, 'r');
plot(x_random, f_random, 'b');
hold off;
ylim([0 1]); xlim([0 max(x_fixed)]);
title('Empirical Cumulative Distribution Function');
xlabel('Mean Firing Rate (Hz)');
ylabel('P(x)');
legend('Fixed', 'Random', 'Location', 'SouthEast');