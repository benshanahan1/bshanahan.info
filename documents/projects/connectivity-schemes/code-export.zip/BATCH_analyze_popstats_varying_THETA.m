fprintf('Comment out ''id'' and set ''plot_type'' to 1 in ''analyze_popstats.m''...\n');
pause;

stime = tic;

% id = 'random_THETA';
% analyze_popstats;
% random_frV = frV;
% random_xV = xV;
% 
% id = 'fixed-in_THETA';
% analyze_popstats;
% fixedin_frV = frV;
% fixedin_xV = xV;
%
% id = 'small-world*K=6*THETA';
% analyze_popstats;
% smallworld_6_frV = frV;
% smallworld_6_xV = xV;
% id = 'small-world*K=10*THETA';
% analyze_popstats;
% smallworld_10_frV = frV;
% smallworld_10_xV = xV;
% id = 'small-world*K=16*THETA';
% analyze_popstats;
% smallworld_16_frV = frV;
% smallworld_16_xV = xV;

id = '2d_THETA';
analyze_popstats;
distdep2d_frV = frV;
distdep2d_xV = xV;

id = '3d_THETA';
analyze_popstats;
distdep3d_frV = frV;
distdep3d_xV = xV;

close all;

figure; hold on; grid; grid('minor');

% plot(random_xV, random_frV, '.-', 'MarkerSize', 16);
% plot(fixedin_xV, fixedin_frV, '.-', 'MarkerSize', 16);
% plot(smallworld_6_xV, smallworld_6_frV, '.-', 'MarkerSize', 16);
% plot(smallworld_10_xV, smallworld_10_frV, '.-', 'MarkerSize', 16);
% plot(smallworld_16_xV, smallworld_16_frV, '.-', 'MarkerSize', 16);
plot(distdep2d_xV, distdep2d_frV, '.-', 'MarkerSize', 16);
plot(distdep3d_xV, distdep3d_frV, '.-', 'MarkerSize', 16);

hold off;

% legend('Random','Fixed-Input','Small-World: K=6','Small-World: K=10','Small-World: K=16','Distance-Dependent 2D','Distance-Dependent 3D','location','best');
% legend('Random', 'Fixed-Input', 'location','best');
legend('Distance-Dependent 2D', 'Distance-Dependent 3D', 'location', 'SouthEast');
title('Population Mean Firing Rate vs THETA');
xlabel('THETA (Amperes)');
ylabel('Mean Firing Rate (Hz)');

toc(stime);