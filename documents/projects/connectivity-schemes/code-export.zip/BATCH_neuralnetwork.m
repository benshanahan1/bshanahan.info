% Batch script for processing multiple Neural Network Simulations.
% Benjamin Shanahan, 20150509

close all;
clear; clc;

starttime = tic;

%% VARY: THETA
schemes = {'fixed-in', 'random'};
for s = schemes
    scheme = s{1};
    all_THETA = linspace(1.01e-8, 15e-9, 6); % theta values
    for THETA = all_THETA
        idStr = sprintf('THETA=%0.3d', THETA);
        fprintf(['Now processing network with ' idStr '...\n']);
        neuralnetwork;
    end
end

%% VARY: k for both 2D and 3D distance dependent connectivity schemes
% numSteps = 6;
% schemes = {'uniform-dist-dep-2d',         'uniform-dist-dep-3d'        };
% all_k =   {linspace(-250, -50, numSteps), linspace(-125, -25, numSteps)};
% for s = 1 : numel(schemes)
%     scheme = schemes{s};
%     for k = all_k{s}
%         idStr = sprintf('k=%04d', k);
%         fprintf(['Now processing network with ' idStr '...\n']);
%         args = k;
%         neuralnetwork;
%     end
% end

%% VARY: degree for random and fixed connectivity schemes
% schemes =     {'random',              'fixed'};
% all_degrees = {[.1 .125 .15 .175 .2], [10 50 100 150 200 500]};
% for s = 1 : numel(schemes)
%     scheme = schemes{s};
%     for degree = all_degrees{s}
%         idStr = sprintf('degree=%04d', degree);
%         fprintf(['Now processing network with ' idStr '...\n']);
%         args = degree;
%         neuralnetwork;
%     end
% end

%% DONE
fprintf(sprintf('TOTAL time elapsed is %.3f seconds.\n', toc(starttime)));