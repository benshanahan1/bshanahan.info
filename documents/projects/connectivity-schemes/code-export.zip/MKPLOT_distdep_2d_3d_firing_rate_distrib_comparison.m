% plot firing rate distribution for both distance-dependent 2D and 3D

numBins = 15;

load('../data/NETWORK_20150511024219_uniform-dist-dep-2d_THETA=1.010e-08.mat');
analysis; drawnow; close all; drawnow;
nmf2d = neuron_mean_fr;
[co2d, ce2d] = hist(neuron_mean_fr, numBins);

load('../data/NETWORK_20150511101052_uniform-dist-dep-3d_THETA=1.010e-08.mat');
analysis; drawnow; close all; drawnow;
nmf3d = neuron_mean_fr;
[co3d, ce3d] = hist(neuron_mean_fr, numBins);

figure;
grid; grid('minor');

hold on;

plot(ce2d, co2d, '.-', 'MarkerSize', 16);
plot(ce3d, co3d, '.-', 'MarkerSize', 16);

hold off;

title('Distance Dependent Firing Rate Distributions');
xlabel('Firing Rate (Hz)');
ylabel('Frequency');

legend('Distance-Dependent 2D', 'Distance-Dependent 3D', 'location', 'NorthEast');



% run kolmogorov-smirnov test to determine distribution similarity or
% dissimilarity
[H, P, ks2stat] = kstest2(full(nmf2d), full(nmf3d));
if H == 1
    fprintf('REJECT: distrib. are statistically different.\n');
else
    fprintf('FAIL to REJECT: distrib. are not statistically different.\n');
end