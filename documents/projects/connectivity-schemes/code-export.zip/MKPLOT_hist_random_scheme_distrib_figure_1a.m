% generate side-by-side of random scheme input distributions

figure;

subplot(2, 1, 1);
hist(sum(full(W_e)/EPSC_peak, 2), 10);
set(gca, 'XTick', [50 120 200]);
ylabel('Freq.');
xlabel('E input');
xlim([50 200]);
grid('minor');

subplot(2, 1, 2);
hist(sum(full(W_i)/IPSC_peak, 2), 10);
set(gca, 'XTick', [0 30 60]);
xlabel('I input');
ylabel('Freq.');
xlim([0 60]);
grid('minor');