% generate periodogram comparison plot for first 2 values in savestruct
% see plot_type == 3 in analyze_popstats.m for more info

% to get savestruct, run analyze_popstats with plot_type = 3.

figure;

hold on;
plot(savestruct.file1_freq, savestruct.file1_normPxx);
plot(savestruct.file2_freq, savestruct.file2_normPxx);
hold off;

xlim([0 70]);
ylim([0 0.035]);

grid; grid('minor');

title('Periodogram Power Spectra Density Comparison');
xlabel('Frequency (Hz)');
ylabel('Normalized Magnitude');

legend('THETA = 1.010e-8 A', 'THETA = 1.108e-8 A', 'Location', 'NorthEast');