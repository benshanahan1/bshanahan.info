% Analysis for Neural Networks
% Benjamin Shanahan, 20150422

%% PREPARE RASTER PLOT
neurons2disp = 5e3;
bins2disp = neurons2disp;

% allocate sparse matrix for spikes
all_spikes = spalloc(N, bins, round(50 * N * duration));

for t = 1 : bins
    all_spikes(:,t) = double(spiking{t});
end

% get locations of spikes in all_spikes matrix
[neuron, bin] = find(all_spikes);

dispneurons = neuron(neuron <= neurons2disp);
dispbins = bin(neuron <= bins2disp);

%% ANALYSIS
% population firing rate
w = 0.001; % window size, in seconds
net_activity = full(sum(all_spikes, 1)); % sum down columns

% divide net spiking activity in bins of size w/dt
windowsize = w / dt;
numwindows = bins / windowsize;
net_activity_binned = sum(reshape(net_activity, windowsize, numwindows),1);
x = (1 : numwindows) * w;

% determine the firing rate (rate = number / time)
fr = net_activity_binned / N / w;

% normalize outliers to net average
rem_outliers = false;
mult = 2; % max allowable std distance from mean
fr_max = mean(fr) + mult * std(fr);
fr_min = 1e4;
if rem_outliers
    fr(fr > fr_max) = mean(fr);
    fr(fr < fr_min) = mean(fr);
end

% smooth fr and display overlay on same plot
blur_window_width = 0.005; % blurring window width, in seconds
halfwidth = (blur_window_width / dt) / 2;
gauss_filter = gausswin(blur_window_width / dt); % create gaussian window
gauss_filter = gauss_filter / sum(gauss_filter); % normalize
fr_smoothed = conv(fr, gauss_filter);
fr_smoothed = fr_smoothed(halfwidth : end - halfwidth);

%% PLOTTING
% raster plot
figure; hold on;
ha(1) = subplot(2, 1, 1);
plot(dispbins * dt, dispneurons, '.k');
xlabel('Time (seconds)');
ylabel('Neuron');

% plot population firing rate
ha(2) = subplot(2, 1, 2);
hold on;
plot(x, fr);
plot(x, fr_smoothed, 'LineWidth', 2);
grid;
title(sprintf('Population Firing Rate, window width = %0.3f s', w));
xlabel('Time (seconds)');
ylabel('Firing Rate (Hz)');
legend('Firing Rate', 'Firing Rate, Smoothed', 'Location', 'Best');
ylim([0 max(fr_smoothed)]);
hold off;

% link axes so we can scroll plots together
linkaxes(ha, 'x');

% print mean firing rate for ALL neurons
fprintf(['Mean firing rate (all neurons): ' ...
    num2str(mean(all_spikes(:))/dt) ' Hz.\n']);

% plot histogram of mean firing rates distribution
neuron_mean_fr = sum(all_spikes, 2) / duration;
figure;
hist(neuron_mean_fr, 20); grid; grid('minor');
title('Distribution of Neuronal Firing Rates');
xlabel('Firing Rate (Hz)');
ylabel('Number of Neurons in Bin');

% plot histogram with distribution of interspike intervals
figure;
temp_spikes = reshape(permute(all_spikes, [2 1]), numel(all_spikes), 1);
pop_ISIs = diff(find(temp_spikes)) * dt;
hist(pop_ISIs, 30); grid;
title('Distribution of All Interspike Intervals');
xlabel('Interspike Interval Duration (seconds)');
ylabel('Number of ISIs in Bin');

% % plot distribution of coefficients of variation of interspike intervals
% figure; grid;
% CVs = NaN(N,1);
% % TODO find a more efficient way of finding CVs for all neurons (see below)
% for n = 1 : N
%     isi = diff(bin(neuron == n)) * dt;
%     CVs(n) = std(isi) / mean(isi);
% end
% CVs = CVs(CVs ~= 0);
% hist(CVs, 30); grid;
% title('Distribution of CVs of ISIs');
% xlabel('CV Values');
% ylabel('Number of CVs in Bin');

% %% INDIVIDUAL NEURONS
% for i = 1 : length(neurons2watch)
%     figure;
%     V = saved_V(i, :);
%     spikes = logical(full(all_spikes(neurons2watch(i),:)));
%     V(spikes) = V_peak; % add in spikes
%     plot((1:bins) * dt, V, 'k'); grid;
%     title(['Membrane Potential of Neuron ' int2str(neurons2watch(i))]);
%     xlabel('Time (seconds)');
%     ylabel('Membrane Potential (Volts)');
% end