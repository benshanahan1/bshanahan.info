% ANALYZE DATA
% Benjamin Shanahan, 20150510
%
% analyze mean firing rate for all distance dependent connectivity versus
% both varying THETA and K
%
% analyze mean firing rate in all plots versus total number of E/I spikes
% (to illustrate that with decreased connections (ie INHIB) the network can
% actually fire a lot more.

meanfrtime = tic;

% preallocate storage vectors
frV = [];
spV_tot = [];
spV_e = [];
spV_i = [];
osc = [];
meanV = [];
stdV = [];
xV = [];

% change the following params
id = 'fixed-in_THETA';
xVar = 'THETA'; % variable to load for x-axis of final plot
use_k = true;
% Plot types:
%    1 = meanfr vs theta/k
%    2 = totalspikes vs theta/k
%    3 = determine periodicity w autocorr
%    4 = quantify firing rate fluctuations
plot_type = 1;

datadir = '../data/';
files = dir([datadir '*' id '*']);

for f = 1 : numel(files)
    
    fprintf(['Processing File ' int2str(f) '...']);
    
    file = [datadir files(f).name];
    
    load(file, 'spiking', 'N', 'N_e', 'N_i', 'bins', 'dt', 'duration', ...
        xVar);
    
    all_spikes = spalloc(N, bins, round(50 * N * duration));
    for t = 1 : bins
        all_spikes(:,t) = double(spiking{t});
    end
    
    if plot_type == 1 % meanfr vs theta/k
        meanfr = full(mean(all_spikes(:)) / dt);
        frV = [frV; meanfr];
    elseif plot_type == 2 % totalspikes vs theta/k
        spV_tot = [spV_tot; sum(sum(all_spikes))];
        spV_e = [spV_e; sum(sum(all_spikes(1:N_e, :)))];
        spV_i = [spV_i; sum(sum(all_spikes(N_e+1:N, :)))];
    elseif plot_type == 3 % determine periodicity w autocorr
        w = 0.005; % window size, in seconds
        netA = full(sum(all_spikes, 1)); % net activity
        sizeW = w / dt;
        nW = bins / sizeW; % window size and number
        netA_binned = sum(reshape(netA, sizeW, nW),1); % bin net activity
        frX = (1 : nW) * w; % x-axis for firing rate
        fr = netA_binned / w; % population firing rate
        
        % calculate periodogram to quantify oscillations
        fs = nW / duration; % sample rate (windows per second)
        [pxx, freq] = periodogram(fr, [], [], fs);
        
        % quantify oscillatory behavior
        [pks, locs] = findpeaks(pxx, freq, ...
            'minPeakDistance', 10);
        peak_freq = diff(locs);
        avg_osc_cycle = nanmean(peak_freq);
        osc = [osc; avg_osc_cycle];
        
        % visualize periodogram with peaks highlighted
        plot_periodogram = true;
        show_peaks = false;
        if plot_periodogram
            figure; grid;
            hold on;
            plot(freq, pxx/max(pxx), 'k');
            saveOutPeriodogram = true;
            if saveOutPeriodogram
                savestruct.(['file' int2str(f) '_freq']) = freq;
                savestruct.(['file' int2str(f) '_normPxx']) = pxx/max(pxx);
            end
            if show_peaks
                plot(locs, pks, 'og');
            end
            hold off;
            title('Periodogram Power Spectra Density Estimate');
            xlabel('Cycles per Second');
            ylabel('Normalized Magnitude');
            drawnow;
        end
    elseif plot_type == 4 % quantify smoothed firing rate fluctuations
        analysis; drawnow; close all; drawnow; % get smoothed firing rate
        meanV = [meanV; mean(fr)];
        stdV = [stdV; std(fr)];
    else
        error('Unknown plot type.');
    end
    
    if use_k
        info = eval(xVar);
        xV = [xV; info.k];
    else
        xV = [xV; eval(xVar)];
    end
    
    fprintf('done.\n');
    
end

if use_k
    xStr = 'K';
else
    xStr = xVar;
end

toc(meanfrtime);

%% Plot data
markerSize = 15;
if plot_type == 1
    figure;
    plot(xV, frV, '.-k', 'MarkerSize', markerSize);
    title(['Population Mean Firing Rate vs ' xStr]);
    xlabel(xStr);
    ylabel('Firing Rate (Hz)');
    grid; grid('minor');
elseif plot_type == 2
    figure;
    subplot(211);
    hold on;
    plot(xV, spV_tot, '.-k', 'MarkerSize', markerSize);
    plot(xV, spV_e, '.-g', 'MarkerSize', markerSize);
    plot(xV, spV_i, '.-r', 'MarkerSize', markerSize);
    grid; grid('minor');
    title(['Spike Counts vs ' xStr]);
    xlabel(xStr);
    ylabel('Number of Spikes');
    legend('Total', 'Excit', 'Inhib', 'Location', 'Best');
    hold off;
    subplot(212);
    plot(xV, (spV_e ./ spV_i)*100, '.-', 'MarkerSize', markerSize);
    grid; grid('minor');
    title('Inhibitory Neurons: Percentage of Total Spike Count');
    xlabel(xStr);
    ylabel('Percent (%)');
elseif plot_type == 3
    figure;
    plot(xV, osc, '.-k', 'MarkerSize', markerSize);
    title('Network Oscillatory Behavior');
    xlabel(xStr);
    ylabel('Cycles per Second');
    grid; grid('minor');
elseif plot_type == 4
    figure;
    hold on;
    plot(xV, meanV, 'k');
    plot(xV, meanV+stdV, 'r');
    plot(xV, meanV-stdV, 'r');
    hold off;
    title('Population Mean Firing Rate with Standard Error');
    xlabel(xStr);
    ylabel('Firing Rate (Hz)');
    grid; grid('minor');
end

%% SUPPRESS SYNTAX HIGHLIGHTER ERRORS
%#ok<*AGROW>
%#ok<*UNRCH>