function z = bmswap(z,N)
% function z = bmswap(z,N)
%
% z (input) is a binary matrix
% z (output) is a binary matrix with the same row and column sums as the original
%
% N is the number of gibbs sampling iterations
%
% z (output) is chosen uniformly among all such binary matrics for large enough N

[m,n] = size(z);
for k = 1:N
    
    % pick two rows
    r1 = randi(m); r2 = randi(m-1); if r2 == r1, r2 = m; end
    % find mismatches
    ndx = find(z(r1,:)~=z(r2,:));
    % permute mismatches
    ndx2 = ndx(randperm(numel(ndx)));
    z([r1 r2],ndx) = z([r1 r2],ndx2);
    
    % pick two cols
    c1 = randi(n); c2 = randi(n-1); if c2 == c1, c2 = n; end
    % find mismatches
    ndx = find(z(:,c1)~=z(:,c2));
    % permute mismatches
    ndx2 = ndx(randperm(numel(ndx)));
    z(ndx,[c1 c2]) = z(ndx2,[c1 c2]);
    
end
