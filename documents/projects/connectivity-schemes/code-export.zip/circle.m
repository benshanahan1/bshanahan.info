function circle(x, y, r)
% plot a circle

ang = 0 : 0.01 : 2*pi;
dx = r * cos(ang);
dy = r * sin(ang);
plot(x + dx, y + dy);

return;