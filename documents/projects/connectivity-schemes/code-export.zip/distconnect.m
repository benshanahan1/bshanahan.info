function W = distconnect(k, x, y, z)
% W = distconnect(k, x, y, z)
% Matthew Lee, 20150503
% Generate connectivity matrix based on distance between neurons and a
% connection threshold (k). The 'z' parameter is optional, if excluded,
% use 2D, else use 3D.
%
% Changed connectivity determination from hard threshold to soft boundary
% determined by exponential decay function: probability of connection
% decays with distance from neuron. Parameter 'k' is exponential decay
% constant and the following values are recommended:
%  
% Neurons distributed inside circle:
%    -50 > k > -250
%
% Neurons distributed inside sphere:
%    -25 > k > -125

if nargin == 3
    z = NaN;
    do_3d = false;
else
    do_3d = true;
end

len = [numel(x) numel(y) numel(z)];
if do_3d
    if any(len ~= len(1))
        error('Please make sure all position vectors have same length.');
    end
else
    if len(1) ~= len(2)
        error('Please make sure all position vectors have same length.');
    end
end

% instantiate variables
N = numel(x);

% combine all positions into a single matrix so we can use pdist
if do_3d
    P = horzcat(x, y, z);
else
    P = horzcat(x, y);
end

% compute pairwise distances
D = pdist(P, 'euclidean');
D = squareform(D); % re-form matrix

% calculate probability of connection over distance (P(x))
% x = 0 : .001 : 1; area(x, exp(k * x)); grid; grid('minor');
P = exp(k * D);
P = P - eye(N);

% generate random N*N matrix
R = rand(N);

% compare randMat and P to determine connections & cast as double
W = double(R < P);

% % compute pairwise distances and re-form into square matrix
% D = pdist(P, 'euclidean');
% D = squareform(D);
% 
% % find values less than threshold, compare them to a random threshold, and
% % if they are larger than it, create a connection
% idx = find(D <= cthr);
% rthr = rand(1, 1); % random threshold
% W(idx) = (1 ./ (1 + D(idx))) > rthr;
% W = W - eye(N); % remove self connections (distance will always be zero)

return;

%#ok<*UNRCH>