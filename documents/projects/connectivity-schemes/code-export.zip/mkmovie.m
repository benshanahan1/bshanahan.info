function mkmovie(az_init, el_init, save2disk, savedir)
% mkmovie(az_init, el_init)
% Benjamin Shanahan, 20150504
% Generate a rotating movie of a 3D plot. The parameters are both optional
% and specify initial azimuth and elevation for 3D plot.

if nargin == 0
    az = 45;
    el = 30;
    save2disk = false;
else
    az = az_init;
    el = el_init;
    
    if ~exist('save2disk','var')
        save2disk = false;
    end
end

if save2disk && ~exist(savedir,'dir')
    mkdir(savedir);
end

% set view to initial rotation
view(az, el);

rots = 0 : 2 : 360;
for i = 1 : numel(rots)
    view(rots(i) + az, el);
    pause(1e-6);
    
    if save2disk
        savename = sprintf('mkmovie_%04d.png', i);
        saveas(1, [savedir savename]);
    end
end

return;