% Functional Model of Neural Network with N Neurons.
% Contains 80% excitatory neurons and 20% inhibitory neurons.
%
% Recommended simulation time is 3 seconds, with population of 10000
% neurons.
%
% Benjamin Shanahan, 20150315. Last modified, 20150329.
%
% Code for PARAMETERS, NETWORK SETUP, RASTER PLOT by Elie Bienenstock

%% CLEAN UP INTERFACE
% close all;
% clear; clc;
network = []; % save structure

%% START TIMER
networkstarttime = tic;

%% SIMULATION PARAMETERS
duration = 10; % simulation length in seconds
dt = 0.0001; % timestep in seconds (equal to 0.1 ms)
neurons2watch = [1 2 9999 10000]; % save membrane potentials for these

% choose connectivity scheme for network (uncomment scheme to use)
% scheme = 'random';
% scheme = 'fixed';
scheme = 'fixed-in';
% scheme = 'small-world';
% scheme = 'uniform-dist-dep-2d';
% scheme = 'uniform-dist-dep-3d';

% update save structure for parameters
network.duration = duration;
network.dt = dt;
network.neurons2watch = neurons2watch;
network.scheme = scheme;

%% PARAMETERS
% Default values for network parameters:
%    R_m = 1e6; % membrane resistance Ohm
%    C_m = 2e-8; % membrane capacitance F
%    tau_e = 0.005; % exc. syn. time constant s
%    tau_i = 0.010; % inh. syn. time constant s
%    tau_m = R_m * C_m; % membrane time constant s
%    V_rest = -0.06; % resting potential V
%    V_reset = -0.06; % reset potential V
%    V_thr = -0.05; % threshold V
%    V_peak = 0.05; % peak of action potential V
%    EPSC_peak = 1.6e-9; % peak epsc A
%    IPSC_peak = -8.7e-9; % peak ipsc A
%    refractory_period = 0.005; % absolute refract. period s
%    THETA = 15e-9; % constant current A

THETA = 1.01e-8;

R_m = 1e6; % membrane resistance Ohm
C_m = 2e-8; % membrane capacitance F
tau_e = 0.005; % exc. syn. time constant s
tau_i = 0.010; % inh. syn. time constant s
tau_m = R_m * C_m; % membrane time constant s
V_rest = -0.06; % resting potential V
V_reset = -0.06; % reset potential V
V_thr = -0.05; % threshold V
V_peak = 0.05; % peak of action potential V
EPSC_peak = 1.6e-9; % peak epsc A
IPSC_peak = -8.7e-9; % peak ipsc A
refractory_period = 0.005; % absolute refract. period s
if ~exist('THETA','var')
    THETA = 15e-9; % constant current A
end
initial_perturbation = .01; % necessary to break symmetries

tic;

% update save structure for parameters
network.R_m = R_m;
network.C_m = C_m;
network.tau_e = tau_e;
network.tau_i = tau_i;
network.tau_m = tau_m;
network.V_rest = V_rest;
network.V_reset = V_reset;
network.V_thr = V_thr;
network.V_peak = V_peak;
network.EPSC_peak = EPSC_peak;
network.IPSC_peak = IPSC_peak;
network.THETA = THETA;
network.refractory_period = refractory_period;
network.initial_perturbation = initial_perturbation;

%% FILE IDENTIFIER
% prompt user for file identifier
if ~exist('idStr','var') || isempty(idStr)
    idStr = input(['Please enter a filename identifier ' ...
        '(very brief description): '], 's');
end
idStr = regexprep(idStr,' ','_'); % replace spaces with underscores

%% NETWORK SETUP

fprintf('Setting up neural network connectivity matrix.\n');

N = 10000; % number of neurons
N_e = round(N * 0.8); % number of excitatory neurons
N_i = N - N_e; % number of inhibitory neurons

% setup connectivity scheme
if ~exist('args','var') || isempty(args)
    args = [];
end
[W, W_e, W_i, W_info] = setup_connections(N_e, N_i, scheme, args);
drawnow;
toc;

% premultiply connectivity matrices for speed
W_e = W_e * EPSC_peak;
W_i = W_i * IPSC_peak;

% update save structure with connectivity scheme variables
network.N = N;
network.N_e = N_e;
network.N_i = N_i;
network.W = W;
network.W_e = W_e;
network.W_i = W_i;
network.W_info = W_info;

fprintf('Finished network setup.\n');

%% MODEL NETWORK
% where we will be saving our neurons2watch membrane potentials
saved_V = zeros(length(neurons2watch), duration / dt);
saved_I = saved_V;
saved_EPSC = saved_V;
saved_IPSC = saved_V;

% define simulation constants
bins = duration / dt;
network.bins = bins;

% preallocate and initialize column vectors for vector operations
refr = zeros(N, 1); % refractory period
M = zeros(N, 1); % spiking memory (first 0.8*N neurons are excitatory)
tau = [tau_e .* ones(N_e, 1); tau_i .* ones(N_i, 1)];
old_V = V_rest * ones(N, 1) + initial_perturbation * rand(N, 1);
spiking = cell(bins, 1);

% step through simulation
for t = 1 : bins
    % update connectivity matrix with PSCs
    EPSC_tot = W_e * M(1:N_e);
    IPSC_tot = W_i * M((1+N_e):end);
    I = EPSC_tot + IPSC_tot;
    
    % determine membrane potential for neuron population; use tau_m here
    % instead of tau_e or tau_i because we are determining the change of
    % the membrane potential of a neuron, not spiking memory decay
    V = old_V + (V_rest - old_V + THETA * R_m + I * R_m) * dt / tau_m;
    
    % determine which neurons spike (membrane potential is greater than
    % V_thr and refractory period has ended)
    spikes = (V > V_thr) & (refr <= 0);
    
    % if neuron spikes, increase its spiking memory by one but always decay
    % it using tau_s and set its refractory period to refractory_period;
    % also set its membrane potential to V_reset
    M = M - dt ./ tau .* M + spikes;
    refr(spikes) = refractory_period / dt; % # of steps per refr period
    V(spikes) = V_reset;
    
    % store the spiking neurons so we can visualize the model later
    spiking{t} = spikes;
    
    % save membrane potential for comparison at time t + 1
    old_V = V;
    refr = refr - 1; % reduce refractory period counter
    
    % save out neuron V, EPSC, IPSC, and total I
    saved_V(:,t) = V(neurons2watch);
    saved_EPSC(:,t) = EPSC_tot(neurons2watch);
    saved_IPSC(:,t) = IPSC_tot(neurons2watch);
    saved_I(:,t) = I(neurons2watch);
    
    % update user on simulation progress
    num_updates = 50;
    updates = duration / num_updates;
    if (t - updates/dt * floor(t / (updates/dt))) == 0
        fprintf(sprintf('Processed %0.2f / %0.2f seconds. ', ...
            t * dt, duration));
        ta = toc;
        hrs = floor(ta / 3600); ta = ta - 3600 * hrs;
        mins = floor(ta / 60); ta = ta - 60 * mins;
        secs = ta;
        fprintf(sprintf(['Elapsed time is ' ...
            '%d hours, %d minutes, %0.2f seconds.\n'], ...
            hrs, mins, secs));
    end
end

% update save structure for neuron network output
network.spiking = spiking;
network.saved_V = saved_V;
network.saved_EPSC = saved_EPSC;
network.saved_IPSC = saved_IPSC;
network.saved_I = saved_I;

% make sure the save directory exists, if not, create it
saveDir = 'data/';
if ~exist(saveDir,'dir')
    mkdir(saveDir);
end

% save all output to a unique file on disk.
tStr = sprintf('%d%02d%02d%02d%02d%02d', fix(clock));
save([saveDir ...
    'NETWORK_' tStr '_' scheme '_' idStr '.mat'], '-struct', 'network');

toc(networkstarttime);