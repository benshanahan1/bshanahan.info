function plot_network(W, x, y, z, show_neurons)
% plot_network(W, x, y, z)
% Benjamin Shanahan, 20150503
% Plot the connectivity matrix W using spatial locations of neurons and
% gplot (modified function to include both 2D and 3D data). To plot network
% in 2D, either do not pass parameter z, or specify it as [].

N = size(W, 1);
N_e = 0.8*N;
ms = 10; % neuron size on plots
do_3d = true; % don't change this (it is updated below in error checks)

% error checking
if size(W, 1) ~= size(W, 2)
    error('Connectivity matrix must be square.');
end
if nargin == 3
    do_3d = false;
    show_neurons = false;
elseif nargin == 4
    show_neurons = false;
elseif isempty(z)
    do_3d = false;
end
if do_3d
    lengths = [numel(x) numel(y) numel(z)];
else
    lengths = [numel(x) numel(y)];
end
if any(lengths ~= N)
    error(['Dimension mismatch. Make sure that W, x, and y ' ...
        'all have same neuron count.']);
end

% plot the connectivity matrix
figure(1);
hold on;
axis('vis3d'); % make plot display in 1:1 ratio for 2D and 3D

if ~do_3d
    gplot(W, horzcat(x, y), 'k'); % plot nodes and edges in 2D
    
    if show_neurons % add neurons to plot (g = excit, r = inhib)
        plot(x(1:N_e), y(1:N_e), '.g', 'MarkerSize', ms);
        plot(x(N_e+1:N), y(N_e+1:N), '.r', 'MarkerSize', ms);
    end
else
    gplot(W, horzcat(x, y, z), 'k'); % plot nodes and edges in 3D
    
    if show_neurons % add neurons to plot (g = excit, r = inhib)
        range_e = 1 : N_e;
        range_i = (N_e + 1) : N;
        plot3(x(range_e), y(range_e), z(range_e), '.g', 'MarkerSize', ms);
        plot3(x(range_i), y(range_i), z(range_i), '.r', 'MarkerSize', ms);
    end
end

hold off;

return;

%#ok<*UNRCH>