function plot_neuron_connections(neur, W, x, y, z, shownetwork)
% plot_neuron_connections(neur, W, x, y, z, shownetwork)
% Benjamin Shanahan, 20150509
% Plot single neuron and all of its connections in 2- or 3-space.

do_3d = exist('z','var');

markerSize = 15;

figure;
axis vis3d;

if do_3d
    coords = horzcat(x, y, z);
else
    coords = horzcat(x, y);
end

for n = neur
    hold on;
    
    % get efferents and position of selected neuron
    nW_i = find(W(:, n));
    nW_o = find(W(n, :));
    nx_i = x(nW_i);
    ny_i = y(nW_i);
    nx_o = x(nW_o);
    ny_o = y(nW_o);
    if do_3d
        nz_i = z(nW_i);
        nz_o = z(nW_o);
    end
    
    if ~exist('shownetwork','var')
        shownetwork = false;
    end
    if shownetwork
        gplot(W, coords, 'c');
    end
    
    if do_3d
        % central neuron
        x_n = x(n);
        y_n = y(n);
        z_n = z(n);
        
        % draw connections in and out
        for i = 1 : numel(nx_i) % in
            plot3([x_n nx_i(i)], [y_n ny_i(i)], [z_n nz_i(i)], 'r');
        end
        for i = 1 : numel(nx_o) % out
            plot3([x_n nx_o(i)], [y_n ny_o(i)], [z_n nz_o(i)], 'b');
        end
        
        % plot central neuron
        plot3(x_n, y_n, z_n, 'ok', 'MarkerSize', markerSize);
        
        % plot inputs to central neuron
        plot3(nx_i, ny_i, nz_i, '.k', 'MarkerSize', markerSize);
        
        % plot outputs from central neuron
        plot3(nx_o, ny_o, nz_o, '*k', 'MarkerSize', markerSize);
    else
        % central neuron
        x_n = x(n);
        y_n = y(n);
        
        % draw connections in and out
        for i = 1 : numel(nx_i) % in
            plot([x_n nx_i(i)], [y_n ny_i(i)], 'r');
        end
        for i = 1 : numel(nx_o) % out
            plot([x_n nx_o(i)], [y_n ny_o(i)], 'b');
        end
        
        % plot central neuron
        plot(x_n, y_n, 'ok', 'MarkerSize', markerSize);
        
        % plot inputs to central neuron
        plot(nx_i, ny_i, '.k', 'MarkerSize', markerSize);
        
        % plot outputs from central neuron
        plot(nx_o, ny_o, '*k', 'MarkerSize', markerSize);
    end
    
    hold off;
end

title('Selected Neuron with Connections');

return;