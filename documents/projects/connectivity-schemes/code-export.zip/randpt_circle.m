function [x, y] = randpt_circle(n, r, x0, y0)
% [x, y] = randpt_circle(n, r, x0, y0)
% Benjamin Shanahan, 20150503
% Choose n uniformly distributed random points within a circular constraint
% of radius r, centered at (x0, y0). Both x0 and y0 are optional. Default
% value is zero for both.
%
% Modified code from
%    http://www.mathworks.com/matlabcentral/answers/294-generate-random-
%    points-inside-a-circle

if nargin == 2
    x0 = 0;
    y0 = 0;
end

a = 2 * pi * rand(n,1);
r1 = sqrt(rand(n,1));

x = (r * r1) .* cos(a) + x0;
y = (r * r1) .* sin(a) + y0;

return;