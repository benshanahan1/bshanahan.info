function [x, y, z] = randpt_sphere(n, r, x0, y0, z0)
% [x, y, z] = randpt_sphere(n, r, x0, y0, z0)
% Benjamin Shanahan, 20150503
% Choose n uniformly distributed random points within a spherical
% constraint of radius r, centered at (x0, y0, z0). All three points, x0,
% y0, and z0, are optional. Default values are all zero.
%
% Modified code from
%    - http://www.mathworks.com/matlabcentral/answers/353-uniform-
%      distribution-of-n-points-within-a-sphere

if nargin == 2
    x0 = 0;
    y0 = 0;
    z0 = 0;
end

% generate random values for angles and radii in spherical coordinates
cphi = -1 + 2 * rand(n, 1);
sphi = sqrt(1 - cphi.^2);
th1 = 2 * pi * rand(n, 1);
r1 = (rand(n, 1) * (r^3)).^(1/3);
r2 = r1 .* sphi;

% convert from spherical to cartesian coordinates
x = r2 .* sin(th1) + x0;
y = r2 .* cos(th1) + y0;
z = r1 .* cphi + z0;

return;