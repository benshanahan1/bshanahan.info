function [W, W_e, W_i, ret] = setup_connections(N_e, N_i, scheme, args)
% [W, W_e, W_i, ret] = setup_connections(N_e, N_i, scheme, args)
% Benjamin Shanahan, 20150503
% Setup connectivity matrices using different below-defined schemes. Save
% everything out to disk in mat-files. Parameter 'args' is anything you
% want to pass in to the requested connectivity matrix generation function.

ret = [];

% total number of neurons in network
N = N_e + N_i;

%% Connectivity Schemes
if strcmp(scheme, 'random')
    
    % Random Connectivity: number of input connections to each synapse is
    %                      determined by a random variable, code by Elie
    %                      Bienenstock
    if ~exist('args','var') || isempty(args)
        p_connection = 0.015; % probability of synapse from any i to any j
    else
        p_connection = args;
    end
    
    u_bound = round(2 * p_connection * N^2); % max synapse count
    pre = zeros(1, u_bound); % list of presynaptic neurons
    post = zeros(1, u_bound); % list of postsynaptic neurons
    count = 0;
    for i_pre = 1 : N % presynaptic neuron
        i_post = rand(1, N) < p_connection;
        i_post = find(i_post); % postsynaptic neurons
        n_post = length(i_post); % number of neurons postsynaptic to i_pre
        pre(count + (1:n_post)) = i_pre; % update the presynaptic list
        post(count + (1:n_post)) = i_post; % update the postsynaptic list
        count = count + n_post; % update the count of synapses
    end
    pre = pre(1:count); % presynaptic list
    post = post(1:count); % postsynaptic list
    
    W = sparse(post, pre, 1); % connectivity matrix
    
    ret.p_connection = p_connection;
    
elseif strcmp(scheme, 'fixed-in')
    
    % Fixed Input: number of input connections to each neuron is set to a
    %              fixed number
    % Code by Elie Bienenstock, 20150510.
    if ~exist('args','var') || isempty(args)
        p_connection = 0.015;
    else
        p_connection = args;
    end
    
    % All neurons have same excitatory in-degree and same inhibitory
    % in-degree. Out-degrees are binomial/Poisson.
    
    exc_in_degree = N_e * p_connection;
    inh_in_degree = N_i * p_connection;
    tot_in_degree = N * p_connection;
    pre = zeros(1, N * tot_in_degree);
    post = zeros(1, N * tot_in_degree);
    
    for i_post = 1 : N
        e_pre = randperm(N_e, exc_in_degree);
        i_pre = randperm(N_i, inh_in_degree);
        pre((i_post-1)*tot_in_degree + (1:tot_in_degree)) = [e_pre N_e+i_pre];
        post((i_post-1)*tot_in_degree + (1:tot_in_degree)) = i_post;
    end
    
    W = sparse(post, pre, 1);
    
elseif strcmp(scheme, 'fixed')
    
    % Fixed: number of both inputs and outputs to each neuron is fixed
    % bmswap function by Matthew Harrison.
    if ~exist('args','var')
        degree = 150; % number of fixed inputs / outputs per row / col
    else
        degree = args;
    end
    
    numSwaps = 5 * N; % randomization level
    
    fprintf('Generating circulant initial matrix...');
    v = [zeros(1, N-degree) ones(1, degree)];
    W = gallery('circul', v);
    fprintf('done.\nRandomizing circulant matrix...');    
    W = bmswap(W, numSwaps); % use swap code from Matthew Harrison
    W = sparse(W); % convert to sparse
    fprintf('done.\n');
    
    ret.degree = degree;
    ret.numSwaps = numSwaps;
    ret.W = W;
    
elseif strcmp(scheme, 'small-world')
    
    % Small World: set up small-world connectivity scheme (neurons
    %              connected to neighbors in a circular form, but every so
    %              often synapses will rewire to cross the circle
    %     K = 10; % number of nearest neighbors to connect to
    %     p_cut = 0.001; % probability of rewire
    if ~exist('args','var')
        K = 2;
        p_cut = 0.25;
    else
        if numel(args) ~= 2
            error('Parameter ''args'' must be a vector: [K p_cut].');
        else
            K = args(1);
            p_cut = args(2);
        end
    end
    
    W = smallworld(N, K, p_cut);
    
    ret.K = K;
    ret.p_cut = p_cut;
    
elseif strcmp(scheme, 'uniform-dist-dep-2d')
    
    % Distance Dependent 2D: set up uniformly distributed
    %                        distance-dependent connectivity scheme
    %                        (neurons have connection probability that
    %                        varies based on their distance in two-space)
    r = 0.5;
    x0 = 0.5;
    y0 = 0.5;
    %     show_neurons = false;
    
    if ~exist('args','var') || isempty(args)
        k = -50;
    else
        k = args;
    end
    
    [x, y] = randpt_circle(N, r, x0, y0);
    W = distconnect(k, x, y);
    
    %     plot_network(W, x, y, [], show_neurons);
    %     title('Network Connectivity');
    
    ret.k = k;
    ret.r = r;
    ret.x0 = x0;
    ret.y0 = y0;
    ret.x = x;
    ret.y = y;
    
elseif strcmp(scheme, 'uniform-dist-dep-3d')
    
    % Distance Dependent 3D: set up uniformly distributed
    %                        distance-dependent connectivity scheme
    %                        (neurons have connection probability that
    %                        varies based on their distance in three-space)
    r = 0.5;
    x0 = 0.5;
    y0 = 0.5;
    z0 = 0.5;
    %     show_neurons = true;
    
    if ~exist('args','var')
        k = -25;
    else
        k = args;
    end
    
    [x, y, z] = randpt_sphere(N, r, x0, y0, z0);
    W = distconnect(k, x, y, z);
    
    %     plot_network(W, x, y, z, show_neurons);
    %     title('Network Connectivity');
    
    ret.k = k;
    ret.r = r;
    ret.x0 = x0;
    ret.y0 = y0;
    ret.z0 = z0;
    ret.x = x;
    ret.y = y;
    ret.z = z;
    
else
    error('Unrecognized connectivity scheme.');
end

% Generate the excitatory and inhibitory parts of the connectivity matrix.
W_e = W(:, 1:N_e);
W_i = W(:, 1+N_e:N);

return;