function W = smallworld(N,K,p_cut)

%disp(['N = ' num2str(N) '; K = ' num2str(K) '; p = ' num2str(p_cut)])

%% Construct ring of nodes
% each node connected to K/2 nearest neighbors on both sides

t_ring_start = tic;

% v = [0 ones(1,round(K/2)) zeros(1,round(N-(K/2+1))) ones(1,round(K/2))];
% W_0 = gallery('circul',v);

W_0 = zeros(N);
for i = 2:N
    for j = 1:i-1
        if i-j <= K/2
            W_0(i,j) = 1;
        elseif N-(i-j) <= K/2
            W_0(i,j) = 1;
        end
    end
end

t_ring_end = toc(t_ring_start);
%disp(['Ring: ' num2str(t_ring_end)])

%% Watts-Strogatz mechanism
% determine which connections to rewire

t_rewire_start = tic;

edges = find(W_0);  % length = N*K/2
edges_cut = rand([N*K/2 1]) < p_cut;

edges_cut_idx = find(edges_cut);
n_cut = length(edges_cut_idx);

% rewire those connections
W = W_0 + W_0' + eye(N);

for ii = 1:n_cut
    [i,j] = ind2sub([N N],edges(edges_cut_idx(ii)));
    k = i;
    
    while W(i,k) == 1
        k = randi(N);
    end
    W(i,j) = 0;
    W(i,k) = 1;
end

W = W - eye(N);

t_rewire_end = toc(t_rewire_start);
%disp(['Rewire: ' num2str(t_rewire_end)])

%save(['W-N=' num2str(N) '_K=' num2str(K) '_p=' num2str(p_cut) '.mat'],'W');

end