% Small-world network
% Matthew Lee

N = 1e3;    % # nodes
K = 10;    % # connected neighbors
p_cut = [0 1e-4 2.5e-4 5e-4 7.5e-4 1e-3 2.5e-3 5e-3 7.5e-3 0.01 0.025 0.05 0.075 0.1 0.25 0.5 0.75 0.99]; % probability of a connection being rewired
n_run = 20; % # runs per p_cut

n_p = length(p_cut);

W = cell(n_p,n_run);

for ii = 1:n_p
    for jj = 1:n_run
        W{ii,jj} = smallworld(N,K,p_cut(ii));
    end
end

%% Clustering coefficient & path length

max_conn = K*(K-1)/2;
C = zeros(n_p,n_run);
L = C;
C_mean = zeros(n_p,1);
L_mean = C_mean;

for ii = 1:n_p
    for jj = 1:n_run
        C_local = zeros(N,1);

        for v = 1:N
            N_v = find(W{ii}(v,:)); % indices of neighbors
            for i = 1:K-1
                for j = 2:K
                    C_local(v) = C_local(v) + (W{ii}(N_v(i),N_v(j)) == 1);
                end
            end
        end

        C_local = C_local / max_conn;
        C(ii,jj) = mean(C_local);

        [dist] = graphallshortestpaths(sparse(W{ii,jj}),'Directed','false');
        dist = tril(dist);
        dist_sum = sum(sum(dist));
        L(ii,jj) = dist_sum / (N*(N-1));
    end
    
    C_mean(ii) = mean(C(ii,:));
    disp(['Clustering coeff = ' num2str(C_mean(ii)/C_mean(1))])
    
    L_vec = L(ii,:);
    L_mean(ii) = mean(L_vec(isfinite(L_vec)));
    disp(['Path length = ' num2str(L(ii)/L_mean(1))])
end

%% Graphical analysis
figure
hold on
scatter(p_cut,C_mean/C_mean(1))
scatter(p_cut,L_mean/L_mean(1))
set(gca,'xscale','log')
xlabel('probability of rewiring')
legend('Clustering coefficient','Path length','Location','southwest')
hold off